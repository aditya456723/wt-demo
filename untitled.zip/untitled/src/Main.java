import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.sql.*;

public class Main {
    public boolean validate(String username, String date) {
        boolean status = false;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://abcd2.czo24aow0bnr.eu-north-1.rds.amazonaws.com:3306/wt", "abcd2", "adityacc");

            PreparedStatement ps = con.prepareStatement(
                    "select * from users where username=? and date=?");
            ps.setString(1, username);
            ps.setString(2, date);

            ResultSet rs = ps.executeQuery();
            status = rs.next();

        } catch (Exception e) {
            System.out.println(e);
        }
        return status;
    }
}


